<?php
if (isset($_POST['AdminName']) ||
    isset($_POST['UserName']) ||
    isset($_POST['MobileNumber']) ||
    isset($_POST['Email']) ||
    isset($_POST['Password'])) {

    //include('includes/dbconnection.php');
    $localhost="localhost";
    $user="root";
    $password="";
    $database="buspassdb";
    $conn=mysqli_connect($localhost, $user, $password, $database);


    $AdminName = $_POST['AdminName'];
    $UserName = $_POST['UserName'];
    $MobileNumber = $_POST['MobileNumber'];
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    echo $AdminName;
    echo $UserName;
    
    if (empty($UserName)) {
        header("Location: signup.php?ms=UserName is required");
        exit;
    } else if (empty($AdminName)) {
        header("Location: signup.php?ms=AdminName is required");
        exit;
    } else if (empty($MobileNumber)) {
        header("Location: signup.php?ms=MobileNumber is required");
        exit;
    } else if (empty($Email)) {
        header("Location: signup.php?ms=Email is required");
        exit;
    } else if (empty($Password)) {
        header("Location: signup.php?ms=Password is required");
        exit;
    } 
    else {
        // Check if the connection is established before executing queries
        
            $sql = "INSERT INTO tbladmin (ID, AdminName, UserName, MobileNumber, Email, Password) VALUES ('', '$AdminName', '$UserName', '$MobileNumber', '$Email', '$Password')";
            $result = mysqli_query($conn, $sql);

            if ($result) {
                $ms = "Successfully created";  
                header("Location:index.php?ms=$ms");
                exit;
            } else {
                $ms = "Unknown error occurred";
                header("Location: signup.php?ms=$ms");
                exit;
            }
        
} 
    }
?>
