<?php
session_start();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

    
        <div style="text-align: center;">
            <div style="display: inline-block; background-color: #f0f0f0; border-radius: 10px; padding: 20px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); width: 300px;">
            <a href="userindex.php">
            <img src="images/home.png" alt="Home" style="width: 20px; height: 20px; border-radius: 50%; margin-bottom: 10px; margin-left: -220px ;">
            </a>    
                <div style="text-align: center;">
                    <img src="./25694.png" alt="Profile" style="width: 80px; height: 80px; border-radius: 50%;">
                </div>
                <h2><?php echo $_SESSION['username'] ?></h2>
                <h4>#Keep Beliving</h4>
                <p>
                    <span style="font-size: 20px;margin-left:0px ; margin-right: 0px; ">&#128100;</span> Name:<?php echo $_SESSION['username'] ?> <br>
                    

                    <span style="font-size: 20px;">&#9993;</span> Email: <?php echo $_SESSION['email'] ?><br>
                    <span style="font-size: 20px; ">&#9742;</span> Mobile: <?php echo $_SESSION['mobilenumber'] ?>
                </p>
            </div>
        </div>
   
    



       


</body>
</html>